#ifndef TIMER_H_
#define TIMER_H_

#include "main.h"

void timer1_setup(mss_timer_mode_t mode, uint32_t ticks);
void timer2_setup(mss_timer_mode_t mode, uint32_t ticks);

#endif /* TIMER_H_ */
