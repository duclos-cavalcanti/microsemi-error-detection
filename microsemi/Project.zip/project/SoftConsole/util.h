#ifndef __UTIL__H
#define __UTIL__H

#include "main.h"

int sprintf_uart16(uint8_t* buf, int* size, uint16_t value);

#endif /* __UTIL__H */
