#ifndef INJECTION_H_
#define INJECTION_H_

#include "main.h"

uint16_t image_transform_bytes(uint8_t* image);
uint16_t image_inject_err(uint16_t image_payload);

#endif
