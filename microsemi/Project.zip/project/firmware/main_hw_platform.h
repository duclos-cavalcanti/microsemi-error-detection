#ifndef main_HW_PLATFORM_H_
#define main_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Mon Feb  6 21:27:20 2023
*
*Memory map specification for peripherals in main
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Initiator(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/


#endif /* main_HW_PLATFORM_H_*/
