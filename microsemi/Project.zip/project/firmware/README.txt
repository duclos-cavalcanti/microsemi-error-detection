Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v2021.3 (Version 2021.3.0.10)

Date    :    Thu Feb  9 12:07:16 2023
Project :    /home/daniel/Documents/libero_projects/ProjectV2
