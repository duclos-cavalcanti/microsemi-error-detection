#ifndef project_HW_PLATFORM_H_
#define project_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Thu Feb  9 03:03:07 2023
*
*Memory map specification for peripherals in project
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Initiator(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/


#endif /* project_HW_PLATFORM_H_*/
