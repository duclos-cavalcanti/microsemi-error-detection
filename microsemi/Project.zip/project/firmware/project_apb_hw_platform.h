#ifndef project_apb_HW_PLATFORM_H_
#define project_apb_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Thu Feb  9 12:07:16 2023
*
*Memory map specification for peripherals in project_apb
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Initiator(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/
#define EC_SLAVE_0                      0x30000000U


#endif /* project_apb_HW_PLATFORM_H_*/
